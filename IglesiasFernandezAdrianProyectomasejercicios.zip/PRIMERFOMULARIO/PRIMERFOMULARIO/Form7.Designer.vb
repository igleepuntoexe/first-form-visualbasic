﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form7
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.IntroducirEuros = New System.Windows.Forms.TextBox()
        Me.IntroducirDolares = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.DolaresConvertir = New System.Windows.Forms.Button()
        Me.EurosConvertir = New System.Windows.Forms.Button()
        Me.BotonLimpiar = New System.Windows.Forms.Button()
        Me.BotonSalir = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(78, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(58, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Conversor:"
        '
        'IntroducirEuros
        '
        Me.IntroducirEuros.Location = New System.Drawing.Point(145, 107)
        Me.IntroducirEuros.Name = "IntroducirEuros"
        Me.IntroducirEuros.Size = New System.Drawing.Size(135, 20)
        Me.IntroducirEuros.TabIndex = 1
        '
        'IntroducirDolares
        '
        Me.IntroducirDolares.Location = New System.Drawing.Point(147, 149)
        Me.IntroducirDolares.Name = "IntroducirDolares"
        Me.IntroducirDolares.Size = New System.Drawing.Size(132, 20)
        Me.IntroducirDolares.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(302, 109)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(19, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = " € "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(306, 153)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(13, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "$"
        '
        'DolaresConvertir
        '
        Me.DolaresConvertir.Location = New System.Drawing.Point(77, 271)
        Me.DolaresConvertir.Name = "DolaresConvertir"
        Me.DolaresConvertir.Size = New System.Drawing.Size(137, 52)
        Me.DolaresConvertir.TabIndex = 5
        Me.DolaresConvertir.Text = "Convertir a Dolares"
        Me.DolaresConvertir.UseVisualStyleBackColor = True
        '
        'EurosConvertir
        '
        Me.EurosConvertir.Location = New System.Drawing.Point(238, 271)
        Me.EurosConvertir.Name = "EurosConvertir"
        Me.EurosConvertir.Size = New System.Drawing.Size(130, 52)
        Me.EurosConvertir.TabIndex = 6
        Me.EurosConvertir.Text = "Convertir a Euros"
        Me.EurosConvertir.UseVisualStyleBackColor = True
        '
        'BotonLimpiar
        '
        Me.BotonLimpiar.Location = New System.Drawing.Point(394, 271)
        Me.BotonLimpiar.Name = "BotonLimpiar"
        Me.BotonLimpiar.Size = New System.Drawing.Size(120, 52)
        Me.BotonLimpiar.TabIndex = 7
        Me.BotonLimpiar.Text = "Limpiar"
        Me.BotonLimpiar.UseVisualStyleBackColor = True
        '
        'BotonSalir
        '
        Me.BotonSalir.Location = New System.Drawing.Point(540, 271)
        Me.BotonSalir.Name = "BotonSalir"
        Me.BotonSalir.Size = New System.Drawing.Size(117, 51)
        Me.BotonSalir.TabIndex = 8
        Me.BotonSalir.Text = "Salir"
        Me.BotonSalir.UseVisualStyleBackColor = True
        '
        'Form7
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.BotonSalir)
        Me.Controls.Add(Me.BotonLimpiar)
        Me.Controls.Add(Me.EurosConvertir)
        Me.Controls.Add(Me.DolaresConvertir)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.IntroducirDolares)
        Me.Controls.Add(Me.IntroducirEuros)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form7"
        Me.Text = "Form7"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents IntroducirEuros As TextBox
    Friend WithEvents IntroducirDolares As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents DolaresConvertir As Button
    Friend WithEvents EurosConvertir As Button
    Friend WithEvents BotonLimpiar As Button
    Friend WithEvents BotonSalir As Button
End Class
