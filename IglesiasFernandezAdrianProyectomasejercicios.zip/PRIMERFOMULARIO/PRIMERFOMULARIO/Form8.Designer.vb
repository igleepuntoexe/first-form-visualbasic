﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class lblasteriscofechadenacimiento
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.BotonGuardarUsuario = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.BotonRetrocederAlPrincipio = New System.Windows.Forms.Button()
        Me.BotonRetroceder = New System.Windows.Forms.Button()
        Me.BotonAvanzar = New System.Windows.Forms.Button()
        Me.BotonAvanzarAlFinal = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.BotonBuscarUsuario = New System.Windows.Forms.Button()
        Me.BotonEliminarUsuario = New System.Windows.Forms.Button()
        Me.dnibuscar = New System.Windows.Forms.TextBox()
        Me.dnieliminar = New System.Windows.Forms.TextBox()
        Me.dnitxt = New System.Windows.Forms.TextBox()
        Me.correotxt = New System.Windows.Forms.TextBox()
        Me.edadtxt = New System.Windows.Forms.TextBox()
        Me.apellidostxt = New System.Windows.Forms.TextBox()
        Me.nombretxt = New System.Windows.Forms.TextBox()
        Me.nombre2txt = New System.Windows.Forms.TextBox()
        Me.apellidos2txt = New System.Windows.Forms.TextBox()
        Me.edad2txt = New System.Windows.Forms.TextBox()
        Me.correo2txt = New System.Windows.Forms.TextBox()
        Me.fechadenacimiento2txt = New System.Windows.Forms.TextBox()
        Me.dni2txt = New System.Windows.Forms.TextBox()
        Me.BotonLimpiar = New System.Windows.Forms.Button()
        Me.BotonSalir = New System.Windows.Forms.Button()
        Me.BotonValidarUsuario = New System.Windows.Forms.Button()
        Me.BotonVerRegistro = New System.Windows.Forms.Button()
        Me.lblasterisco = New System.Windows.Forms.Label()
        Me.lblasteriscocorreo = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.lblasteriscoapellidos = New System.Windows.Forms.Label()
        Me.lblasteriscoedad = New System.Windows.Forms.Label()
        Me.lblasteriscoDNI = New System.Windows.Forms.Label()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(37, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(90, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Datos Personales"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(37, 47)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Nombre"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(37, 74)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(49, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Apellidos"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(37, 107)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(32, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Edad"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(37, 140)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(38, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Correo"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(37, 166)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(26, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "DNI"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(37, 196)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(108, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Fecha de Nacimiento"
        '
        'BotonGuardarUsuario
        '
        Me.BotonGuardarUsuario.Location = New System.Drawing.Point(40, 238)
        Me.BotonGuardarUsuario.Name = "BotonGuardarUsuario"
        Me.BotonGuardarUsuario.Size = New System.Drawing.Size(106, 43)
        Me.BotonGuardarUsuario.TabIndex = 7
        Me.BotonGuardarUsuario.Text = "Guardar Usuario"
        Me.BotonGuardarUsuario.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(449, 1)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(90, 13)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "Visualizar Usuario"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(449, 196)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(108, 13)
        Me.Label9.TabIndex = 14
        Me.Label9.Text = "Fecha de Nacimiento"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(449, 166)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(26, 13)
        Me.Label10.TabIndex = 13
        Me.Label10.Text = "DNI"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(449, 140)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(38, 13)
        Me.Label11.TabIndex = 12
        Me.Label11.Text = "Correo"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(449, 107)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(32, 13)
        Me.Label12.TabIndex = 11
        Me.Label12.Text = "Edad"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(449, 74)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(49, 13)
        Me.Label13.TabIndex = 10
        Me.Label13.Text = "Apellidos"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(449, 47)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(44, 13)
        Me.Label14.TabIndex = 9
        Me.Label14.Text = "Nombre"
        '
        'BotonRetrocederAlPrincipio
        '
        Me.BotonRetrocederAlPrincipio.Location = New System.Drawing.Point(451, 238)
        Me.BotonRetrocederAlPrincipio.Name = "BotonRetrocederAlPrincipio"
        Me.BotonRetrocederAlPrincipio.Size = New System.Drawing.Size(65, 43)
        Me.BotonRetrocederAlPrincipio.TabIndex = 15
        Me.BotonRetrocederAlPrincipio.Text = "<<"
        Me.BotonRetrocederAlPrincipio.UseVisualStyleBackColor = True
        '
        'BotonRetroceder
        '
        Me.BotonRetroceder.Location = New System.Drawing.Point(522, 238)
        Me.BotonRetroceder.Name = "BotonRetroceder"
        Me.BotonRetroceder.Size = New System.Drawing.Size(63, 43)
        Me.BotonRetroceder.TabIndex = 16
        Me.BotonRetroceder.Text = "<"
        Me.BotonRetroceder.UseVisualStyleBackColor = True
        '
        'BotonAvanzar
        '
        Me.BotonAvanzar.Location = New System.Drawing.Point(591, 237)
        Me.BotonAvanzar.Name = "BotonAvanzar"
        Me.BotonAvanzar.Size = New System.Drawing.Size(61, 44)
        Me.BotonAvanzar.TabIndex = 17
        Me.BotonAvanzar.Text = ">"
        Me.BotonAvanzar.UseVisualStyleBackColor = True
        '
        'BotonAvanzarAlFinal
        '
        Me.BotonAvanzarAlFinal.Location = New System.Drawing.Point(658, 237)
        Me.BotonAvanzarAlFinal.Name = "BotonAvanzarAlFinal"
        Me.BotonAvanzarAlFinal.Size = New System.Drawing.Size(59, 44)
        Me.BotonAvanzarAlFinal.TabIndex = 18
        Me.BotonAvanzarAlFinal.Text = ">>"
        Me.BotonAvanzarAlFinal.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(401, 317)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(79, 13)
        Me.Label15.TabIndex = 19
        Me.Label15.Text = "Buscar Usuario"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(594, 315)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(82, 13)
        Me.Label16.TabIndex = 20
        Me.Label16.Text = "Eliminar Usuario"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(401, 345)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(26, 13)
        Me.Label17.TabIndex = 21
        Me.Label17.Text = "DNI"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(600, 345)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(26, 13)
        Me.Label18.TabIndex = 22
        Me.Label18.Text = "DNI"
        '
        'BotonBuscarUsuario
        '
        Me.BotonBuscarUsuario.Location = New System.Drawing.Point(403, 374)
        Me.BotonBuscarUsuario.Name = "BotonBuscarUsuario"
        Me.BotonBuscarUsuario.Size = New System.Drawing.Size(89, 22)
        Me.BotonBuscarUsuario.TabIndex = 23
        Me.BotonBuscarUsuario.Text = "Buscar Usuario"
        Me.BotonBuscarUsuario.UseVisualStyleBackColor = True
        '
        'BotonEliminarUsuario
        '
        Me.BotonEliminarUsuario.Location = New System.Drawing.Point(598, 374)
        Me.BotonEliminarUsuario.Name = "BotonEliminarUsuario"
        Me.BotonEliminarUsuario.Size = New System.Drawing.Size(95, 21)
        Me.BotonEliminarUsuario.TabIndex = 24
        Me.BotonEliminarUsuario.Text = "Eliminar Usuario"
        Me.BotonEliminarUsuario.UseVisualStyleBackColor = True
        '
        'dnibuscar
        '
        Me.dnibuscar.Location = New System.Drawing.Point(431, 342)
        Me.dnibuscar.Name = "dnibuscar"
        Me.dnibuscar.Size = New System.Drawing.Size(61, 20)
        Me.dnibuscar.TabIndex = 9
        '
        'dnieliminar
        '
        Me.dnieliminar.Location = New System.Drawing.Point(632, 342)
        Me.dnieliminar.Name = "dnieliminar"
        Me.dnieliminar.Size = New System.Drawing.Size(61, 20)
        Me.dnieliminar.TabIndex = 10
        '
        'dnitxt
        '
        Me.dnitxt.Location = New System.Drawing.Point(69, 163)
        Me.dnitxt.Name = "dnitxt"
        Me.dnitxt.Size = New System.Drawing.Size(67, 20)
        Me.dnitxt.TabIndex = 4
        '
        'correotxt
        '
        Me.correotxt.Location = New System.Drawing.Point(81, 137)
        Me.correotxt.Name = "correotxt"
        Me.correotxt.Size = New System.Drawing.Size(247, 20)
        Me.correotxt.TabIndex = 3
        '
        'edadtxt
        '
        Me.edadtxt.Location = New System.Drawing.Point(75, 104)
        Me.edadtxt.Name = "edadtxt"
        Me.edadtxt.Size = New System.Drawing.Size(61, 20)
        Me.edadtxt.TabIndex = 2
        '
        'apellidostxt
        '
        Me.apellidostxt.Location = New System.Drawing.Point(92, 71)
        Me.apellidostxt.Name = "apellidostxt"
        Me.apellidostxt.Size = New System.Drawing.Size(236, 20)
        Me.apellidostxt.TabIndex = 1
        '
        'nombretxt
        '
        Me.nombretxt.Location = New System.Drawing.Point(87, 45)
        Me.nombretxt.Name = "nombretxt"
        Me.nombretxt.Size = New System.Drawing.Size(100, 20)
        Me.nombretxt.TabIndex = 0
        '
        'nombre2txt
        '
        Me.nombre2txt.Location = New System.Drawing.Point(499, 40)
        Me.nombre2txt.Name = "nombre2txt"
        Me.nombre2txt.ReadOnly = True
        Me.nombre2txt.Size = New System.Drawing.Size(100, 20)
        Me.nombre2txt.TabIndex = 38
        '
        'apellidos2txt
        '
        Me.apellidos2txt.Location = New System.Drawing.Point(504, 71)
        Me.apellidos2txt.Name = "apellidos2txt"
        Me.apellidos2txt.ReadOnly = True
        Me.apellidos2txt.Size = New System.Drawing.Size(236, 20)
        Me.apellidos2txt.TabIndex = 37
        '
        'edad2txt
        '
        Me.edad2txt.Location = New System.Drawing.Point(487, 104)
        Me.edad2txt.Name = "edad2txt"
        Me.edad2txt.ReadOnly = True
        Me.edad2txt.Size = New System.Drawing.Size(61, 20)
        Me.edad2txt.TabIndex = 36
        '
        'correo2txt
        '
        Me.correo2txt.Location = New System.Drawing.Point(493, 137)
        Me.correo2txt.Name = "correo2txt"
        Me.correo2txt.ReadOnly = True
        Me.correo2txt.Size = New System.Drawing.Size(247, 20)
        Me.correo2txt.TabIndex = 35
        '
        'fechadenacimiento2txt
        '
        Me.fechadenacimiento2txt.Location = New System.Drawing.Point(563, 193)
        Me.fechadenacimiento2txt.Name = "fechadenacimiento2txt"
        Me.fechadenacimiento2txt.ReadOnly = True
        Me.fechadenacimiento2txt.Size = New System.Drawing.Size(177, 20)
        Me.fechadenacimiento2txt.TabIndex = 34
        '
        'dni2txt
        '
        Me.dni2txt.Location = New System.Drawing.Point(481, 163)
        Me.dni2txt.Name = "dni2txt"
        Me.dni2txt.ReadOnly = True
        Me.dni2txt.Size = New System.Drawing.Size(61, 20)
        Me.dni2txt.TabIndex = 33
        '
        'BotonLimpiar
        '
        Me.BotonLimpiar.Location = New System.Drawing.Point(1, 419)
        Me.BotonLimpiar.Name = "BotonLimpiar"
        Me.BotonLimpiar.Size = New System.Drawing.Size(108, 32)
        Me.BotonLimpiar.TabIndex = 39
        Me.BotonLimpiar.Text = "Limpiar"
        Me.BotonLimpiar.UseVisualStyleBackColor = True
        '
        'BotonSalir
        '
        Me.BotonSalir.Location = New System.Drawing.Point(115, 419)
        Me.BotonSalir.Name = "BotonSalir"
        Me.BotonSalir.Size = New System.Drawing.Size(108, 32)
        Me.BotonSalir.TabIndex = 40
        Me.BotonSalir.Text = "Salir"
        Me.BotonSalir.UseVisualStyleBackColor = True
        '
        'BotonValidarUsuario
        '
        Me.BotonValidarUsuario.Location = New System.Drawing.Point(161, 238)
        Me.BotonValidarUsuario.Name = "BotonValidarUsuario"
        Me.BotonValidarUsuario.Size = New System.Drawing.Size(99, 42)
        Me.BotonValidarUsuario.TabIndex = 6
        Me.BotonValidarUsuario.Text = "Validar Usuario"
        Me.BotonValidarUsuario.UseVisualStyleBackColor = True
        '
        'BotonVerRegistro
        '
        Me.BotonVerRegistro.Location = New System.Drawing.Point(451, 289)
        Me.BotonVerRegistro.Name = "BotonVerRegistro"
        Me.BotonVerRegistro.Size = New System.Drawing.Size(265, 23)
        Me.BotonVerRegistro.TabIndex = 8
        Me.BotonVerRegistro.Text = "Ver Registros"
        Me.BotonVerRegistro.UseVisualStyleBackColor = True
        '
        'lblasterisco
        '
        Me.lblasterisco.AutoSize = True
        Me.lblasterisco.Location = New System.Drawing.Point(196, 47)
        Me.lblasterisco.Name = "lblasterisco"
        Me.lblasterisco.Size = New System.Drawing.Size(11, 13)
        Me.lblasterisco.TabIndex = 43
        Me.lblasterisco.Text = "*"
        '
        'lblasteriscocorreo
        '
        Me.lblasteriscocorreo.AutoSize = True
        Me.lblasteriscocorreo.Location = New System.Drawing.Point(334, 137)
        Me.lblasteriscocorreo.Name = "lblasteriscocorreo"
        Me.lblasteriscocorreo.Size = New System.Drawing.Size(11, 13)
        Me.lblasteriscocorreo.TabIndex = 44
        Me.lblasteriscocorreo.Text = "*"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(357, 196)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(11, 13)
        Me.Label20.TabIndex = 45
        Me.Label20.Text = "*"
        '
        'lblasteriscoapellidos
        '
        Me.lblasteriscoapellidos.AutoSize = True
        Me.lblasteriscoapellidos.Location = New System.Drawing.Point(334, 71)
        Me.lblasteriscoapellidos.Name = "lblasteriscoapellidos"
        Me.lblasteriscoapellidos.Size = New System.Drawing.Size(11, 13)
        Me.lblasteriscoapellidos.TabIndex = 46
        Me.lblasteriscoapellidos.Text = "*"
        '
        'lblasteriscoedad
        '
        Me.lblasteriscoedad.AutoSize = True
        Me.lblasteriscoedad.Location = New System.Drawing.Point(142, 104)
        Me.lblasteriscoedad.Name = "lblasteriscoedad"
        Me.lblasteriscoedad.Size = New System.Drawing.Size(11, 13)
        Me.lblasteriscoedad.TabIndex = 47
        Me.lblasteriscoedad.Text = "*"
        '
        'lblasteriscoDNI
        '
        Me.lblasteriscoDNI.AutoSize = True
        Me.lblasteriscoDNI.Location = New System.Drawing.Point(142, 163)
        Me.lblasteriscoDNI.Name = "lblasteriscoDNI"
        Me.lblasteriscoDNI.Size = New System.Drawing.Size(11, 13)
        Me.lblasteriscoDNI.TabIndex = 48
        Me.lblasteriscoDNI.Text = "*"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(151, 196)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker1.TabIndex = 49
        '
        'lblasteriscofechadenacimiento
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.lblasteriscoDNI)
        Me.Controls.Add(Me.lblasteriscoedad)
        Me.Controls.Add(Me.lblasteriscoapellidos)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.lblasteriscocorreo)
        Me.Controls.Add(Me.lblasterisco)
        Me.Controls.Add(Me.BotonVerRegistro)
        Me.Controls.Add(Me.BotonValidarUsuario)
        Me.Controls.Add(Me.BotonSalir)
        Me.Controls.Add(Me.BotonLimpiar)
        Me.Controls.Add(Me.nombre2txt)
        Me.Controls.Add(Me.apellidos2txt)
        Me.Controls.Add(Me.edad2txt)
        Me.Controls.Add(Me.correo2txt)
        Me.Controls.Add(Me.fechadenacimiento2txt)
        Me.Controls.Add(Me.dni2txt)
        Me.Controls.Add(Me.nombretxt)
        Me.Controls.Add(Me.apellidostxt)
        Me.Controls.Add(Me.edadtxt)
        Me.Controls.Add(Me.correotxt)
        Me.Controls.Add(Me.dnitxt)
        Me.Controls.Add(Me.dnieliminar)
        Me.Controls.Add(Me.dnibuscar)
        Me.Controls.Add(Me.BotonEliminarUsuario)
        Me.Controls.Add(Me.BotonBuscarUsuario)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.BotonAvanzarAlFinal)
        Me.Controls.Add(Me.BotonAvanzar)
        Me.Controls.Add(Me.BotonRetroceder)
        Me.Controls.Add(Me.BotonRetrocederAlPrincipio)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.BotonGuardarUsuario)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "lblasteriscofechadenacimiento"
        Me.Text = "Form8"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents BotonGuardarUsuario As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents BotonRetrocederAlPrincipio As Button
    Friend WithEvents BotonRetroceder As Button
    Friend WithEvents BotonAvanzar As Button
    Friend WithEvents BotonAvanzarAlFinal As Button
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents BotonBuscarUsuario As Button
    Friend WithEvents BotonEliminarUsuario As Button
    Friend WithEvents dnibuscar As TextBox
    Friend WithEvents dnieliminar As TextBox
    Friend WithEvents dnitxt As TextBox
    Friend WithEvents correotxt As TextBox
    Friend WithEvents edadtxt As TextBox
    Friend WithEvents apellidostxt As TextBox
    Friend WithEvents nombretxt As TextBox
    Friend WithEvents nombre2txt As TextBox
    Friend WithEvents apellidos2txt As TextBox
    Friend WithEvents edad2txt As TextBox
    Friend WithEvents correo2txt As TextBox
    Friend WithEvents fechadenacimiento2txt As TextBox
    Friend WithEvents dni2txt As TextBox
    Friend WithEvents BotonLimpiar As Button
    Friend WithEvents BotonSalir As Button
    Friend WithEvents BotonValidarUsuario As Button
    Friend WithEvents BotonVerRegistro As Button
    Friend WithEvents lblasterisco As Label
    Friend WithEvents lblasteriscocorreo As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents lblasteriscoapellidos As Label
    Friend WithEvents lblasteriscoedad As Label
    Friend WithEvents lblasteriscoDNI As Label
    Friend WithEvents DateTimePicker1 As DateTimePicker
End Class
