﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Numero1 = New System.Windows.Forms.TextBox()
        Me.Numero2 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.BotonSumar = New System.Windows.Forms.Button()
        Me.BotonRestar = New System.Windows.Forms.Button()
        Me.BotonMultiplicar = New System.Windows.Forms.Button()
        Me.BotonDividir = New System.Windows.Forms.Button()
        Me.resultado = New System.Windows.Forms.TextBox()
        Me.lblsuma = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(29, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(82, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "MiniCalculadora"
        '
        'Numero1
        '
        Me.Numero1.Location = New System.Drawing.Point(147, 134)
        Me.Numero1.Margin = New System.Windows.Forms.Padding(1, 3, 5, 3)
        Me.Numero1.Name = "Numero1"
        Me.Numero1.Size = New System.Drawing.Size(79, 20)
        Me.Numero1.TabIndex = 1
        '
        'Numero2
        '
        Me.Numero2.Location = New System.Drawing.Point(282, 134)
        Me.Numero2.Name = "Numero2"
        Me.Numero2.Size = New System.Drawing.Size(79, 20)
        Me.Numero2.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(400, 137)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(13, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "="
        '
        'BotonSumar
        '
        Me.BotonSumar.Location = New System.Drawing.Point(151, 248)
        Me.BotonSumar.Name = "BotonSumar"
        Me.BotonSumar.Size = New System.Drawing.Size(74, 70)
        Me.BotonSumar.TabIndex = 4
        Me.BotonSumar.Text = "Sumar"
        Me.BotonSumar.UseVisualStyleBackColor = True
        '
        'BotonRestar
        '
        Me.BotonRestar.Location = New System.Drawing.Point(254, 248)
        Me.BotonRestar.Name = "BotonRestar"
        Me.BotonRestar.Size = New System.Drawing.Size(68, 69)
        Me.BotonRestar.TabIndex = 5
        Me.BotonRestar.Text = "Restar"
        Me.BotonRestar.UseVisualStyleBackColor = True
        '
        'BotonMultiplicar
        '
        Me.BotonMultiplicar.Location = New System.Drawing.Point(357, 248)
        Me.BotonMultiplicar.Name = "BotonMultiplicar"
        Me.BotonMultiplicar.Size = New System.Drawing.Size(65, 69)
        Me.BotonMultiplicar.TabIndex = 6
        Me.BotonMultiplicar.Text = "Multiplicar"
        Me.BotonMultiplicar.UseVisualStyleBackColor = True
        '
        'BotonDividir
        '
        Me.BotonDividir.Location = New System.Drawing.Point(459, 247)
        Me.BotonDividir.Name = "BotonDividir"
        Me.BotonDividir.Size = New System.Drawing.Size(63, 69)
        Me.BotonDividir.TabIndex = 7
        Me.BotonDividir.Text = "Dividir"
        Me.BotonDividir.UseVisualStyleBackColor = True
        '
        'resultado
        '
        Me.resultado.Location = New System.Drawing.Point(434, 134)
        Me.resultado.Name = "resultado"
        Me.resultado.Size = New System.Drawing.Size(87, 20)
        Me.resultado.TabIndex = 8
        '
        'lblsuma
        '
        Me.lblsuma.AutoSize = True
        Me.lblsuma.Location = New System.Drawing.Point(243, 138)
        Me.lblsuma.Name = "lblsuma"
        Me.lblsuma.Size = New System.Drawing.Size(13, 13)
        Me.lblsuma.TabIndex = 9
        Me.lblsuma.Text = "+"
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lblsuma)
        Me.Controls.Add(Me.resultado)
        Me.Controls.Add(Me.BotonDividir)
        Me.Controls.Add(Me.BotonMultiplicar)
        Me.Controls.Add(Me.BotonRestar)
        Me.Controls.Add(Me.BotonSumar)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Numero2)
        Me.Controls.Add(Me.Numero1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form4"
        Me.Text = " "
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Numero1 As TextBox
    Friend WithEvents Numero2 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents BotonSumar As Button
    Friend WithEvents BotonRestar As Button
    Friend WithEvents BotonMultiplicar As Button
    Friend WithEvents BotonDividir As Button
    Friend WithEvents resultado As TextBox
    Friend WithEvents lblsuma As Label
End Class
