﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.BotonCuadrado = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.BotonRectangulo = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.BotonTriangulo = New System.Windows.Forms.Button()
        Me.txtCalculoTotal = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.LadosCuadrado = New System.Windows.Forms.TextBox()
        Me.MedidaMayor = New System.Windows.Forms.TextBox()
        Me.MedidaLadoMenor = New System.Windows.Forms.TextBox()
        Me.BaseTriangulo = New System.Windows.Forms.TextBox()
        Me.AlturaTriangulo = New System.Windows.Forms.TextBox()
        Me.AreaCuadrado = New System.Windows.Forms.TextBox()
        Me.AreaRectangulo = New System.Windows.Forms.TextBox()
        Me.AreaTriangulo = New System.Windows.Forms.TextBox()
        Me.BotonReiniciar = New System.Windows.Forms.Button()
        Me.BotonSalir = New System.Windows.Forms.Button()
        Me.BotonCalculoTotal = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(11, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(87, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Cálculo de Áreas"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 86)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(174, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Medida de los Lados del Cuadrado:"
        '
        'BotonCuadrado
        '
        Me.BotonCuadrado.Location = New System.Drawing.Point(503, 77)
        Me.BotonCuadrado.Name = "BotonCuadrado"
        Me.BotonCuadrado.Size = New System.Drawing.Size(79, 31)
        Me.BotonCuadrado.TabIndex = 2
        Me.BotonCuadrado.Text = "Cuadrado"
        Me.BotonCuadrado.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(13, 178)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(116, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Medida del lado mayor:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(249, 178)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(117, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Medida del lado menor:"
        '
        'BotonRectangulo
        '
        Me.BotonRectangulo.Location = New System.Drawing.Point(503, 163)
        Me.BotonRectangulo.Name = "BotonRectangulo"
        Me.BotonRectangulo.Size = New System.Drawing.Size(80, 28)
        Me.BotonRectangulo.TabIndex = 5
        Me.BotonRectangulo.Text = "Rectangulo"
        Me.BotonRectangulo.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(17, 51)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 13)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Cuadrado"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(13, 137)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(62, 13)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = "Rectangulo"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(13, 226)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(51, 13)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "Triangulo"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(13, 263)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(97, 13)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "Medida de la base:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(249, 263)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(101, 13)
        Me.Label9.TabIndex = 10
        Me.Label9.Text = "Medida de la Altura:"
        '
        'BotonTriangulo
        '
        Me.BotonTriangulo.Location = New System.Drawing.Point(503, 253)
        Me.BotonTriangulo.Name = "BotonTriangulo"
        Me.BotonTriangulo.Size = New System.Drawing.Size(80, 33)
        Me.BotonTriangulo.TabIndex = 11
        Me.BotonTriangulo.Text = "Triangulo"
        Me.BotonTriangulo.UseVisualStyleBackColor = True
        '
        'txtCalculoTotal
        '
        Me.txtCalculoTotal.AutoSize = True
        Me.txtCalculoTotal.Location = New System.Drawing.Point(17, 322)
        Me.txtCalculoTotal.Name = "txtCalculoTotal"
        Me.txtCalculoTotal.Size = New System.Drawing.Size(94, 13)
        Me.txtCalculoTotal.TabIndex = 12
        Me.txtCalculoTotal.Text = "CALCULO TOTAL"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(158, 323)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(78, 13)
        Me.Label10.TabIndex = 13
        Me.Label10.Text = "Área Cuadrado"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(263, 323)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(87, 13)
        Me.Label11.TabIndex = 14
        Me.Label11.Text = "Área Rectangulo"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(369, 322)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(76, 13)
        Me.Label12.TabIndex = 15
        Me.Label12.Text = "Área Triangulo"
        '
        'LadosCuadrado
        '
        Me.LadosCuadrado.Location = New System.Drawing.Point(191, 83)
        Me.LadosCuadrado.Name = "LadosCuadrado"
        Me.LadosCuadrado.Size = New System.Drawing.Size(61, 20)
        Me.LadosCuadrado.TabIndex = 16
        '
        'MedidaMayor
        '
        Me.MedidaMayor.Location = New System.Drawing.Point(135, 175)
        Me.MedidaMayor.Name = "MedidaMayor"
        Me.MedidaMayor.Size = New System.Drawing.Size(73, 20)
        Me.MedidaMayor.TabIndex = 17
        '
        'MedidaLadoMenor
        '
        Me.MedidaLadoMenor.Location = New System.Drawing.Point(372, 175)
        Me.MedidaLadoMenor.Name = "MedidaLadoMenor"
        Me.MedidaLadoMenor.Size = New System.Drawing.Size(65, 20)
        Me.MedidaLadoMenor.TabIndex = 18
        '
        'BaseTriangulo
        '
        Me.BaseTriangulo.Location = New System.Drawing.Point(122, 260)
        Me.BaseTriangulo.Name = "BaseTriangulo"
        Me.BaseTriangulo.Size = New System.Drawing.Size(86, 20)
        Me.BaseTriangulo.TabIndex = 19
        '
        'AlturaTriangulo
        '
        Me.AlturaTriangulo.Location = New System.Drawing.Point(363, 261)
        Me.AlturaTriangulo.Name = "AlturaTriangulo"
        Me.AlturaTriangulo.Size = New System.Drawing.Size(73, 20)
        Me.AlturaTriangulo.TabIndex = 20
        '
        'AreaCuadrado
        '
        Me.AreaCuadrado.Location = New System.Drawing.Point(167, 349)
        Me.AreaCuadrado.Name = "AreaCuadrado"
        Me.AreaCuadrado.Size = New System.Drawing.Size(54, 20)
        Me.AreaCuadrado.TabIndex = 21
        '
        'AreaRectangulo
        '
        Me.AreaRectangulo.Location = New System.Drawing.Point(266, 349)
        Me.AreaRectangulo.Name = "AreaRectangulo"
        Me.AreaRectangulo.Size = New System.Drawing.Size(58, 20)
        Me.AreaRectangulo.TabIndex = 22
        '
        'AreaTriangulo
        '
        Me.AreaTriangulo.Location = New System.Drawing.Point(372, 349)
        Me.AreaTriangulo.Name = "AreaTriangulo"
        Me.AreaTriangulo.Size = New System.Drawing.Size(61, 20)
        Me.AreaTriangulo.TabIndex = 23
        '
        'BotonReiniciar
        '
        Me.BotonReiniciar.Location = New System.Drawing.Point(219, 11)
        Me.BotonReiniciar.Name = "BotonReiniciar"
        Me.BotonReiniciar.Size = New System.Drawing.Size(104, 25)
        Me.BotonReiniciar.TabIndex = 24
        Me.BotonReiniciar.Text = "Reiniciar"
        Me.BotonReiniciar.UseVisualStyleBackColor = True
        '
        'BotonSalir
        '
        Me.BotonSalir.Location = New System.Drawing.Point(347, 11)
        Me.BotonSalir.Name = "BotonSalir"
        Me.BotonSalir.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BotonSalir.Size = New System.Drawing.Size(97, 25)
        Me.BotonSalir.TabIndex = 25
        Me.BotonSalir.Text = "Salir"
        Me.BotonSalir.UseVisualStyleBackColor = True
        '
        'BotonCalculoTotal
        '
        Me.BotonCalculoTotal.Location = New System.Drawing.Point(468, 11)
        Me.BotonCalculoTotal.Name = "BotonCalculoTotal"
        Me.BotonCalculoTotal.Size = New System.Drawing.Size(88, 25)
        Me.BotonCalculoTotal.TabIndex = 26
        Me.BotonCalculoTotal.Text = "Cálculo Total"
        Me.BotonCalculoTotal.UseVisualStyleBackColor = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.BotonCalculoTotal)
        Me.Controls.Add(Me.BotonSalir)
        Me.Controls.Add(Me.BotonReiniciar)
        Me.Controls.Add(Me.AreaTriangulo)
        Me.Controls.Add(Me.AreaRectangulo)
        Me.Controls.Add(Me.AreaCuadrado)
        Me.Controls.Add(Me.AlturaTriangulo)
        Me.Controls.Add(Me.BaseTriangulo)
        Me.Controls.Add(Me.MedidaLadoMenor)
        Me.Controls.Add(Me.MedidaMayor)
        Me.Controls.Add(Me.LadosCuadrado)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txtCalculoTotal)
        Me.Controls.Add(Me.BotonTriangulo)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.BotonRectangulo)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.BotonCuadrado)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents BotonCuadrado As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents BotonRectangulo As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents BotonTriangulo As Button
    Friend WithEvents txtCalculoTotal As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents LadosCuadrado As TextBox
    Friend WithEvents MedidaMayor As TextBox
    Friend WithEvents MedidaLadoMenor As TextBox
    Friend WithEvents BaseTriangulo As TextBox
    Friend WithEvents AlturaTriangulo As TextBox
    Friend WithEvents AreaCuadrado As TextBox
    Friend WithEvents AreaRectangulo As TextBox
    Friend WithEvents AreaTriangulo As TextBox
    Friend WithEvents BotonReiniciar As Button
    Friend WithEvents BotonSalir As Button
    Friend WithEvents BotonCalculoTotal As Button
End Class
