﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.HorasIntroducidas = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.MinutosConvertidos = New System.Windows.Forms.TextBox()
        Me.Segundos = New System.Windows.Forms.Label()
        Me.SegundosConvertidos = New System.Windows.Forms.TextBox()
        Me.HorasConversión = New System.Windows.Forms.Button()
        Me.SalirEjercicio3 = New System.Windows.Forms.Button()
        Me.LimpiadorConversion = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(27, 11)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(183, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Pasar de horas a minutos y segundos"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(248, 172)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Horas:"
        '
        'HorasIntroducidas
        '
        Me.HorasIntroducidas.Location = New System.Drawing.Point(306, 169)
        Me.HorasIntroducidas.Name = "HorasIntroducidas"
        Me.HorasIntroducidas.Size = New System.Drawing.Size(159, 20)
        Me.HorasIntroducidas.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(187, 223)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(47, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Minutos:"
        '
        'MinutosConvertidos
        '
        Me.MinutosConvertidos.Location = New System.Drawing.Point(251, 220)
        Me.MinutosConvertidos.Name = "MinutosConvertidos"
        Me.MinutosConvertidos.Size = New System.Drawing.Size(60, 20)
        Me.MinutosConvertidos.TabIndex = 4
        '
        'Segundos
        '
        Me.Segundos.AutoSize = True
        Me.Segundos.Location = New System.Drawing.Point(361, 225)
        Me.Segundos.Name = "Segundos"
        Me.Segundos.Size = New System.Drawing.Size(58, 13)
        Me.Segundos.TabIndex = 5
        Me.Segundos.Text = "Segundos:"
        '
        'SegundosConvertidos
        '
        Me.SegundosConvertidos.Location = New System.Drawing.Point(441, 220)
        Me.SegundosConvertidos.Name = "SegundosConvertidos"
        Me.SegundosConvertidos.Size = New System.Drawing.Size(71, 20)
        Me.SegundosConvertidos.TabIndex = 6
        '
        'HorasConversión
        '
        Me.HorasConversión.Location = New System.Drawing.Point(289, 266)
        Me.HorasConversión.Name = "HorasConversión"
        Me.HorasConversión.Size = New System.Drawing.Size(175, 50)
        Me.HorasConversión.TabIndex = 7
        Me.HorasConversión.Text = "Convertir"
        Me.HorasConversión.UseVisualStyleBackColor = True
        '
        'SalirEjercicio3
        '
        Me.SalirEjercicio3.Location = New System.Drawing.Point(605, 336)
        Me.SalirEjercicio3.Name = "SalirEjercicio3"
        Me.SalirEjercicio3.Size = New System.Drawing.Size(195, 62)
        Me.SalirEjercicio3.TabIndex = 8
        Me.SalirEjercicio3.Text = "Salir"
        Me.SalirEjercicio3.UseVisualStyleBackColor = True
        '
        'LimpiadorConversion
        '
        Me.LimpiadorConversion.Location = New System.Drawing.Point(0, 336)
        Me.LimpiadorConversion.Name = "LimpiadorConversion"
        Me.LimpiadorConversion.Size = New System.Drawing.Size(165, 61)
        Me.LimpiadorConversion.TabIndex = 9
        Me.LimpiadorConversion.Text = "Limpiar"
        Me.LimpiadorConversion.UseVisualStyleBackColor = True
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.LimpiadorConversion)
        Me.Controls.Add(Me.SalirEjercicio3)
        Me.Controls.Add(Me.HorasConversión)
        Me.Controls.Add(Me.SegundosConvertidos)
        Me.Controls.Add(Me.Segundos)
        Me.Controls.Add(Me.MinutosConvertidos)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.HorasIntroducidas)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form3"
        Me.Text = "Form3"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents HorasIntroducidas As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents MinutosConvertidos As TextBox
    Friend WithEvents Segundos As Label
    Friend WithEvents SegundosConvertidos As TextBox
    Friend WithEvents HorasConversión As Button
    Friend WithEvents SalirEjercicio3 As Button
    Friend WithEvents LimpiadorConversion As Button
End Class
