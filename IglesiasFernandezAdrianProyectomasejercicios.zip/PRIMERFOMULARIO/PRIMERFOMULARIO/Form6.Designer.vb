﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form6
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.centrigradostxt = New System.Windows.Forms.TextBox()
        Me.farenhetitxtç = New System.Windows.Forms.TextBox()
        Me.BotonFareheit = New System.Windows.Forms.Button()
        Me.BotonCentrigrados = New System.Windows.Forms.Button()
        Me.BotonLimpiar = New System.Windows.Forms.Button()
        Me.BotonSalir = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(130, 160)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Grados Centigrados"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(139, 201)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(91, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Grados Farenheid"
        '
        'centrigradostxt
        '
        Me.centrigradostxt.Location = New System.Drawing.Point(266, 157)
        Me.centrigradostxt.Name = "centrigradostxt"
        Me.centrigradostxt.Size = New System.Drawing.Size(83, 20)
        Me.centrigradostxt.TabIndex = 2
        '
        'farenhetitxtç
        '
        Me.farenhetitxtç.Location = New System.Drawing.Point(265, 194)
        Me.farenhetitxtç.Name = "farenhetitxtç"
        Me.farenhetitxtç.Size = New System.Drawing.Size(84, 20)
        Me.farenhetitxtç.TabIndex = 3
        '
        'BotonFareheit
        '
        Me.BotonFareheit.Location = New System.Drawing.Point(394, 148)
        Me.BotonFareheit.Name = "BotonFareheit"
        Me.BotonFareheit.Size = New System.Drawing.Size(136, 29)
        Me.BotonFareheit.TabIndex = 4
        Me.BotonFareheit.Text = "Convertir a Farenheit"
        Me.BotonFareheit.UseVisualStyleBackColor = True
        '
        'BotonCentrigrados
        '
        Me.BotonCentrigrados.Location = New System.Drawing.Point(394, 189)
        Me.BotonCentrigrados.Name = "BotonCentrigrados"
        Me.BotonCentrigrados.Size = New System.Drawing.Size(135, 28)
        Me.BotonCentrigrados.TabIndex = 5
        Me.BotonCentrigrados.Text = "Convertir a Centigrados"
        Me.BotonCentrigrados.UseVisualStyleBackColor = True
        '
        'BotonLimpiar
        '
        Me.BotonLimpiar.Location = New System.Drawing.Point(568, 148)
        Me.BotonLimpiar.Name = "BotonLimpiar"
        Me.BotonLimpiar.Size = New System.Drawing.Size(90, 68)
        Me.BotonLimpiar.TabIndex = 6
        Me.BotonLimpiar.Text = "Limpiar"
        Me.BotonLimpiar.UseVisualStyleBackColor = True
        '
        'BotonSalir
        '
        Me.BotonSalir.Location = New System.Drawing.Point(704, 344)
        Me.BotonSalir.Name = "BotonSalir"
        Me.BotonSalir.Size = New System.Drawing.Size(102, 58)
        Me.BotonSalir.TabIndex = 7
        Me.BotonSalir.Text = "Salir"
        Me.BotonSalir.UseVisualStyleBackColor = True
        '
        'Form6
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.BotonSalir)
        Me.Controls.Add(Me.BotonLimpiar)
        Me.Controls.Add(Me.BotonCentrigrados)
        Me.Controls.Add(Me.BotonFareheit)
        Me.Controls.Add(Me.farenhetitxtç)
        Me.Controls.Add(Me.centrigradostxt)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form6"
        Me.Text = "Form6"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents centrigradostxt As TextBox
    Friend WithEvents farenhetitxtç As TextBox
    Friend WithEvents BotonFareheit As Button
    Friend WithEvents BotonCentrigrados As Button
    Friend WithEvents BotonLimpiar As Button
    Friend WithEvents BotonSalir As Button
End Class
